import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.servlet.*;
import javax.servlet.http.*;

public class g4 extends HttpServlet
{
     public void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
     {
         res.setContentType("text/html");
         PrintWriter pw=res.getWriter();
         try
         {
            HttpSession ses=req.getSession();
            String v1=(String)ses.getAttribute("l1");
            String v2=(String)ses.getAttribute("l3");
            String v3=(String)ses.getAttribute("l4");
            String v4=(String)ses.getAttribute("l5");
            String v5=(String)ses.getAttribute("l6");
            Integer v6=(Integer)ses.getAttribute("l7");
            Integer v7=(Integer)ses.getAttribute("l8");
            String v8=(String)ses.getAttribute("l9");
            String v9=(String)ses.getAttribute("l10");
            String v10=(String)ses.getAttribute("l11");
            String v11=(String)ses.getAttribute("l12");
            String v12=(String)ses.getAttribute("l20");
            
            Class.forName("oracle.jdbc.driver.OracleDriver");
                 //registering type4 driver
               Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","ujjwal3","das1");
               Statement stmt=con.createStatement();
               String q2="insert into alt values('"+v1+"','"+v2+"','"+v3+"','"+v4+"','"+v5+"',"+v6+","+v7+",'"+v8+"','"+v9+"','"+v10+"','"+v11+"')";
               int x=stmt.executeUpdate(q2);
               if(x>0)
               {
                   pw.println("Name:"+v1+"</br>");
            pw.println("Source:"+v2+"</br>");
            pw.println("Destination:"+v3+"</br>");
            pw.println("Journey Date:"+v4+"</br>");
            pw.println("Journey Time:"+v5+"</br>");
            pw.println("Total Price:"+v6+"</br>");
            pw.println("No. of persons:"+v7+"</br>");
            pw.println("Seat numbers:"+v12+"</br>");
            pw.println("Email Id:"+v8+"</br>");
            pw.println("Contact Number:"+v9+"</br>");
            pw.println("Passengers's name:"+v10+"</br>");
            pw.println("Card Type:"+v11+"</br>");
            pw.println("<a href=\"javascript:window.print()\">Print</a>");
               }
               else
               {
                   pw.println("unsuccess");
               }
         }
         catch(Exception e)
         {}
         }  
     }   