import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.servlet.*;
import javax.servlet.http.*;



public class h3 extends HttpServlet
{
  public void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
  {
      res.setContentType("text/html");
      PrintWriter pw1=res.getWriter();
      String na=req.getParameter("m1");
      String na1=req.getParameter("m2");
      String na2=req.getParameter("m3");
     
      
    try
         {
              HttpSession ses=req.getSession();//establishing a session
             ses.setAttribute("l3", na);
             ses.setAttribute("l4", na1);
             ses.setAttribute("l5", na2);
              Class.forName("oracle.jdbc.driver.OracleDriver");
                 //registering type4 driver
               Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","ujjwal3","das1");
               Statement stmt=con.createStatement();
               String q2="insert into ud2 values('"+na+"','"+na1+"','"+na2+"')";
               int x=stmt.executeUpdate(q2);
               if(x>0)
               {
                   
                  if((na.equals("Asansol") && na1.equals("Kolkata"))||(na.equals("Asansol") && na1.equals("Karunamoyee")))
                  {
                   pw1.println("<!--\n" +
"Author: W3layouts\n" +
"Author URL: http://w3layouts.com\n" +
"License: Creative Commons Attribution 3.0 Unported\n" +
"License URL: http://creativecommons.org/licenses/by/3.0/\n" +
"-->\n" +
"<!DOCTYPE HTML>\n" +
"<html>\n" +
"<head>\n" +
"<title>Green Wheels a Travel Category Flat Bootstrap Responsive Website Template | Bus :: w3layouts</title>\n" +
"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
"<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n" +
"<meta name=\"keywords\" content=\"Green Wheels Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, \n" +
"Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design\" />\n" +
"<script type=\"applijewelleryion/x-javascript\"> addEventListener(\"load\", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>\n" +
"<link href=\"css3/bootstrap.css\" rel='stylesheet' type='text/css' />\n" +
"<link href=\"css3/style.css\" rel='stylesheet' type='text/css' />\n" +
"<link href='//fonts3.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>\n" +
"<link href='//fonts3.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>\n" +
"<link href='//fonts3.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>\n" +
"<link href=\"css3/font-awesome.css\" rel=\"stylesheet\">\n" +
"<style>\n" +
"     div.banner{\n" +
"    width: 100%;\n" +
"    height: 100%;\n" +
"    background-image: url('banner.jpg');\n" +
"    background-repeat: no-repeat;\n" +
"     }\n" +
"     input[type=text] {\n" +
"   background-color:white;\n" +
"    border: none;\n" +
"    color: Black;\n" +
"    padding: 8px 16px;\n" +
"    text-decoration: none;\n" +
"    margin: 4px 2px;\n" +
"    cursor: pointer;\n" +
" }\n" +
" input[type=submit] {\n" +
"   background-color:green;\n" +
"    border: none;\n" +
"    color: Black;\n" +
"    padding: 8px 16px;\n" +
"    text-decoration: none;\n" +
"    margin: 4px 2px;\n" +
"    cursor: pointer;\n" +
" }\n" +
"</style>\n" +
"<!-- Custom Theme files -->\n" +
"<script src=\"js3/jquery-1.12.0.min.js\"></script>\n" +
"<script src=\"js3/bootstrap.min.js\"></script>\n" +
"<!--animate-->\n" +
"<link href=\"css3/animate.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\">\n" +
"<script src=\"js3/wow.min.js\"></script>\n" +
"	<script>\n" +
"		 new WOW().init();\n" +
"	</script>\n" +
"<!--//end-animate-->\n" +
"</head>\n" +
"<body>\n" +
"<!-- top-header -->\n" +
"<div class=\"top-header\">\n" +
"	<div class=\"container\">\n" +
"		<ul class=\"tp-hd-lft wow fadeInLeft animated\" data-wow-delay=\".5s\">\n" +
"			<li class=\"prnt\"><a href=\"javascript:window.print()\">Print/SMS Ticket</a></li>\n" +
"				\n" +
"		</ul>\n" +
"		<ul class=\"tp-hd-rgt wow fadeInRight animated\" data-wow-delay=\".5s\"> \n" +
"			<li class=\"tol\">Toll Number : 123-4568790</li>				\n" +
"			<li><a href=\"b1.html\" >Log out</a></li> \n" +
"        </ul>\n" +
"		<div class=\"clearfix\"></div>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /top-header ---->\n" +
"<!--- header ---->\n" +
"<div class=\"header\">\n" +
"	<div class=\"container\">\n" +
"		<div class=\"logo wow fadeInDown animated\" data-wow-delay=\".5s\">\n" +
"			<a href=\"b2.html\">Home <span></span></a>	\n" +
"		</div>\n" +
"		<div class=\"bus wow fadeInUp animated\" data-wow-delay=\".5s\">\n" +           
"           \n" +
"        </div>\n" +
"		<div class=\"lock fadeInDown animated\" data-wow-delay=\".5s\"> \n" +
"            <li><div class=\"securetxt\">SAFE &amp; SECURE<br> ONLINE PAYMENTS</div></li>\n" +
"			<div class=\"clearfix\"></div>\n" +
"		</div>\n" +
"		<div class=\"clearfix\"></div>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /header ---->\n" +
"<!--- footer-btm ---->\n" +
"<div class=\"footer-btm wow fadeInLeft animated\" data-wow-delay=\".5s\">\n" +
"	<div class=\"container\">\n" +
"	<div class=\"navigation\">\n" +
"			<nav class=\"navbar navbar-default\">\n" +
"				<!-- Brand and toggle get grouped for better mobile display -->\n" +
"				<div class=\"navbar-header\">\n" +
"				  <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\">\n" +
"					<span class=\"sr-only\">Toggle navigation</span>\n" +
"					<span class=\"icon-bar\"></span>\n" +
"					<span class=\"icon-bar\"></span>\n" +
"					<span class=\"icon-bar\"></span>\n" +
"				  </button>\n" +
"				</div>\n" +
"				<!-- Collect the nav links, forms, and other content for toggling -->\n" +
"				<div class=\"collapse navbar-collapse nav-wil\" id=\"bs-example-navbar-collapse-1\">\n" +
"					<nav class=\"cl-effect-1\">\n" +
"						<ul class=\"nav navbar-nav\">\n" +
"							<li><a href=\"about.html\">About</a></li>\n" +
"								<li><a href=\"privacy.html\">Privacy Policy</a></li>\n" +
								
"								<li><a href=\"terms.html\">Terms of Use</a></li>\n" +
								
"								<li>Need Help?<a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal3\"> / Write Us </a>  </li>\n" +
"								<div class=\"clearfix\"></div>\n" +
"						</ul>\n" +
"					</nav>\n" +
"				</div><!-- /.navbar-collapse -->	\n" +
"			</nav>\n" +
"		</div>\n" +
"		\n" +
"		<div class=\"clearfix\"></div>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /footer-btm ---->\n" +
"<!--- banner-1 ---->\n" +
"<div class=\"banner\">\n" +
"	<div class=\"container\">\n" +
"		<h1 class=\"wow zoomIn animated animated\" data-wow-delay=\".5s\" style=\"visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;\">Online Bus Booking System</h1>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /banner-1 ---->\n" +
"<!--- bus-tp ---->\n" +
"<div class=\"bus-tp\">\n" +
"	<div class=\"container\">\n" +
"		<p>Fare starts from : Rs. 400/-</p>\n" +
"		<h2>Buses from Asansol to Kolkata or Karunamoyee</h2>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /bus-tp ---->\n" +
"<!--- bus-btm ---->\n" +
"<div class=\"bus-btm\">\n" +
"	\n" +
"</div>\n" +
"<!--- /bus-btm ---->\n" +
"<!--- bus-midd ---->\n" +
"       <table border=\"0\" align=\"center\">\n" +
"    <tr>\n" +
"         <th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Time</th>\n" +
"        <th>&nbsp;&nbsp;&nbsp;Fare</th>\n" +
"         <tr>\n" +
"        <form method=\"post\" action=\"s1\">\n" +
"               <td><input type=\"text\" name=\"c1\" value=\"6:00-11:00(4:00 hrs)\" ></td><td><input type=\"text\" name=\"r1\"  value=\"400/-\" ></td>\n" +
"         <td><input type=\"submit\" value=\"view\"></td>\n" +
"               </form></tr>\n" +
"          <tr>\n" +
"      <form method=\"post\" action=\"s1\">\n" +
"               <td><input type=\"text\"   name=\"c1\" value=\"  8:00-12:00(4:00 hrs)\" ></td><td><input type=\"text\"  name=\"r1\"  value=\"400/-\" ></td>\n" +
"              <td><input type=\"submit\" value=\"view\"></td>\n" +
"             </form></tr>\n" +
"  <tr>\n" +
"    <form method=\"post\" action=\"s1\">\n" +
"             <td><input type=\"text\"   name=\"c1\" value=\"  11:00-15:30(4:30 hrs)\" ></td><td><input type=\"text\"  name=\"r1\"  value=\"400/-\" ></td>\n" +
"             <td><input type=\"submit\" value=\"view\"></td>\n" +
"              </form></tr>\n" +
"       <tr>\n" +
"     <form method=\"post\" action=\"s1\">\n" +
"                <td><input type=\"text\"   name=\"c1\" value=\"  13:00-17:30(4:30 hrs)\" ></td><td><input type=\"text\"  name=\"r1\"  value=\"400/-\" ></td>\n" +
"               <td><input type=\"submit\" value=\"view\"></td>\n" +
"              </form></td></tr>\n" +
"        <tr>\n" +
"     <form method=\"post\" action=\"s1\">\n" +
"               <td><input type=\"text\"   name=\"c1\" value=\"  15:00-19:30(4:30 hrs)\" ></td><td><input type=\"text\"  name=\"r1\"  value=\"400/-\" ></td>\n" +
"              <td><input type=\"submit\" value=\"view\"></td>\n" +
"              </form></tr>\n" +
"       <tr>\n" +
"     <form method=\"post\" action=\"s1\">\n" +
"                <td><input type=\"text\"   name=\"c1\" value=\"  18:00-22:30(4:30 hrs)\" ></td><td><input type=\"text\"  name=\"r1\"  value=\"400/-\" ></td>\n" +
"               <td><input type=\"submit\" value=\"view\"></td>\n" +
"               </form></tr>\n" +
"         </table>\n" +
"\n" +
"                 \n" +
"<!--- /bus-midd ---->\n" +
"<!--- footer-top ---->\n" +
"<div class=\"footer-top\">\n" +
"	<div class=\"container\">\n" +
"		\n" +
"		<div class=\"col-md-6 footer-left wow fadeInRight animated\" data-wow-delay=\".5s\">\n" +
"			<h3>Bus Routes</h3>\n" +
"				<ul>\n" +
"					<li>Asansol-Durgapur </li>\n" +
"					<li>Asansol-Kolkata</li>\n" +
"					<li>Asansol-Karunamoyee</li>\n" +
"					<li>Durgapur-Kolkata</a></li>\n" +
"					<li>Durgapur-Karunamoyee</a></li>\n" +
"					<li>Burdwan-Kolkata</a></li>\n" +
"					<li>Burdwan-Karunamoyee</li>\n" +
"				</ul>\n" +
"		</div>\n" +
"		<div class=\"clearfix\"></div>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /footer-top ---->\n" +
"<!---copy-right ---->\n" +
"<div class=\"copy-right\">\n" +
"	<div class=\"container\">\n" +
"	\n" +
"		<div class=\"footer-social-icons wow fadeInDown animated animated\" data-wow-delay=\".5s\" style=\"visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;\">\n" +
"			<ul>\n" +
"				<li><a class=\"facebook\" href=\"#\"><span>Facebook</span></a></li>\n" +
"				<li><a class=\"twitter\" href=\"#\"><span>Twitter</span></a></li>\n" +
"				<li><a class=\"flickr\" href=\"#\"><span>Flickr</span></a></li>\n" +
"				<li><a class=\"googleplus\" href=\"#\"><span>Google+</span></a></li>\n" +
"				<li><a class=\"dribbble\" href=\"#\"><span>Dribbble</span></a></li>\n" +
"			</ul>\n" +
"		</div>\n" +
"		<p class=\"wow zoomIn animated animated\" data-wow-delay=\".5s\" style=\"visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;\">© 2016 Green Wheels . All Rights Reserved | Design by  <a href=\"http://w3layouts.com/\" target=\"_blank\">W3layouts</a> </p>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /copy-right ---->\n" +
"<!-- sign -->\n" +
"			<div class=\"modal fade\" id=\"myModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\">\n" +
"				<div class=\"modal-dialog\" role=\"document\">\n" +
"					<div class=\"modal-content\">\n" +
"						<div class=\"modal-header\">\n" +
"							<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>						\n" +
"						</div>\n" +
"							<section>\n" +
"								<div class=\"modal-body modal-spa\">\n" +
"									<div class=\"login-grids\">\n" +
"										<div class=\"login\">\n" +
"											<div class=\"login-left\">\n" +
"												<ul>\n" +
"													<li><a class=\"fb\" href=\"#\"><i></i>Sign in with Facebook</a></li>\n" +
"													<li><a class=\"goog\" href=\"#\"><i></i>Sign in with Google</a></li>\n" +
"													<li><a class=\"linkin\" href=\"#\"><i></i>Sign in with Linkedin</a></li>\n" +
"												</ul>\n" +
"											</div>\n" +
"											<div class=\"login-right\">\n" +
"												<form>\n" +
"													<h3>Create your account </h3>\n" +
"													<input type=\"text\" value=\"Name\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Name';}\" required=\"\">\n" +
"													<input type=\"text\" value=\"Mobile number\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Mobile number';}\" required=\"\">\n" +
"													<input type=\"text\" value=\"Email id\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Email id';}\" required=\"\">	\n" +
"													<input type=\"password\" value=\"Password\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Password';}\" required=\"\">	\n" +
"													<input type=\"submit\" value=\"CREATE ACCOUNT\">\n" +
"												</form>\n" +
"											</div>\n" +
"												<div class=\"clearfix\"></div>								\n" +
"										</div>\n" +
"											<p>By logging in you agree to our <a href=\"terms.html\">Terms and Conditions</a> and <a href=\"privacy.html\">Privacy Policy</a></p>\n" +
"									</div>\n" +
"								</div>\n" +
"							</section>\n" +
"					</div>\n" +
"				</div>\n" +
"			</div>\n" +
"<!-- //sign -->\n" +
"<!-- signin -->\n" +
"		<div class=\"modal fade\" id=\"myModal4\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\">\n" +
"				<div class=\"modal-dialog\" role=\"document\">\n" +
"					<div class=\"modal-content modal-info\">\n" +
"						<div class=\"modal-header\">\n" +
"							<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">×</span></button>						\n" +
"						</div>\n" +
"						<div class=\"modal-body modal-spa\">\n" +
"							<div class=\"login-grids\">\n" +
"								<div class=\"login\">\n" +
"									<div class=\"login-left\">\n" +
"										<ul>\n" +
"											<li><a class=\"fb\" href=\"#\"><i></i>Sign in with Facebook</a></li>\n" +
"											<li><a class=\"goog\" href=\"#\"><i></i>Sign in with Google</a></li>\n" +
"											<li><a class=\"linkin\" href=\"#\"><i></i>Sign in with Linkedin</a></li>\n" +
"										</ul>\n" +
"									</div>\n" +
"									<div class=\"login-right\">\n" +
"										<form>\n" +
"											<h3>Signin with your account </h3>\n" +
"											<input type=\"text\" value=\"Enter your mobile number or Email\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Enter your mobile number or Email';}\" required=\"\">	\n" +
"											<input type=\"password\" value=\"Password\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Password';}\" required=\"\">	\n" +
"											<h4><a href=\"#\">Forgot password</a></h4>\n" +
"											<div class=\"single-bottom\">\n" +
"												<input type=\"checkbox\" id=\"brand\" value=\"\">\n" +
"												<label for=\"brand\"><span></span>Remember Me.</label>\n" +
"											</div>\n" +
"											<input type=\"submit\" value=\"SIGNIN\">\n" +
"										</form>\n" +
"									</div>\n" +
"									<div class=\"clearfix\"></div>								\n" +
"								</div>\n" +
"								<p>By logging in you agree to our <a href=\"terms.html\">Terms and Conditions</a> and <a href=\"privacy.html\">Privacy Policy</a></p>\n" +
"							</div>\n" +
"						</div>\n" +
"					</div>\n" +
"				</div>\n" +
"			</div>\n" +
"<!-- //signin -->\n" +
"<!-- write us -->\n" +
"			<div class=\"modal fade\" id=\"myModal3\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\">\n" +
"				<div class=\"modal-dialog\" role=\"document\">\n" +
"					<div class=\"modal-content\">\n" +
"						<div class=\"modal-header\">\n" +
"							<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>						\n" +
"						</div>\n" +
"							<section>\n" +
"								<div class=\"modal-body modal-spa\">\n" +
"									<div class=\"writ\">\n" +
"										<h4>HOW CAN WE HELP YOU</h4>\n" +
"                                                                                                                                                                                                 <form method=\"post\" action=\"\">\n" +
"											<ul>\n" +
"												<li class=\"na-me\">\n" +
"													<input class=\"name\" type=\"text\" value=\"Name\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Name';}\" required=\"\">\n" +
"												</li>\n" +
"												<li class=\"na-me\">\n" +
"													<input class=\"Email\" type=\"text\" value=\"Email\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Email';}\" required=\"\">\n" +
"												</li>\n" +
"												<li class=\"na-me\">\n" +
"													<input class=\"number\" type=\"text\" value=\"Mobile Number\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Mobile Number';}\" required=\"\">\n" +
"												</li>\n" +
"												<li class=\"na-me\">\n" +
"													<select id=\"country\" onchange=\"change_country(this.value)\" class=\"frm-field required sect\">\n" +
"														<option value=\"null\">Select Issue</option> 		\n" +
"														<option value=\"null\">Booking Issues</option>\n" +
"														<option value=\"null\">Bus Cancellation</option>\n" +
"														<option value=\"null\">Refund</option>\n" +
"														<option value=\"null\">Wallet</option>														\n" +
"													</select>\n" +
"												</li>\n" +
"												<li class=\"na-me\">\n" +
"													<select id=\"country\" onchange=\"change_country(this.value)\" class=\"frm-field required sect\">\n" +
"														<option value=\"null\">Select Issue</option> 		\n" +
"														<option value=\"null\">Booking Issues</option>\n" +
"														<option value=\"null\">Bus Cancellation</option>\n" +
"														<option value=\"null\">Refund</option>\n" +
"														<option value=\"null\">Wallet</option>														\n" +
"													</select>\n" +
"												</li>\n" +
"												<li class=\"descrip\">\n" +
"													<input class=\"special\" type=\"text\" value=\"Write Description\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Write Description';}\" required=\"\">\n" +
"												</li>\n" +
"													<div class=\"clearfix\"></div>\n" +
"											</ul>\n" +
"											<div class=\"sub-bn\">\n" +
"												\n" +
"													<input type=\"submit\" value=\"submit\">\n" +
"												\n" +
"											</div>\n" +
"                                                                                                                                                                                      </form>\n" +
"									</div>\n" +
"								</div>\n" +
"							</section>\n" +
"					</div>\n" +
"				</div>\n" +
"			</div>\n" +
"<!-- //write us -->\n" +
"</body>\n" +
"</html>");
                  }
                  else
                      if((na.equals("Durgapur") && na1.equals("Kolkata"))||(na.equals("Durgapur") && na1.equals("Karunamoyee")) )
                      {
                          pw1.println("<!--\n" +
"Author: W3layouts\n" +
"Author URL: http://w3layouts.com\n" +
"License: Creative Commons Attribution 3.0 Unported\n" +
"License URL: http://creativecommons.org/licenses/by/3.0/\n" +
"-->\n" +
"<!DOCTYPE HTML>\n" +
"<html>\n" +
"<head>\n" +
"<title>Green Wheels a Travel Category Flat Bootstrap Responsive Website Template | Bus :: w3layouts</title>\n" +
"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
"<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n" +
"<meta name=\"keywords\" content=\"Green Wheels Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, \n" +
"Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design\" />\n" +
"<script type=\"applijewelleryion/x-javascript\"> addEventListener(\"load\", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>\n" +
"<link href=\"css3/bootstrap.css\" rel='stylesheet' type='text/css' />\n" +
"<link href=\"css3/style.css\" rel='stylesheet' type='text/css' />\n" +
"<link href='//fonts3.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>\n" +
"<link href='//fonts3.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>\n" +
"<link href='//fonts3.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>\n" +
"<link href=\"css3/font-awesome.css\" rel=\"stylesheet\">\n" +
"<style>\n" +
"     div.banner{\n" +
"    width: 100%;\n" +
"    height: 100%;\n" +
"    background-image: url('banner.jpg');\n" +
"    background-repeat: no-repeat;\n" +
"     }\n" +
"     input[type=text] {\n" +
"   background-color:white;\n" +
"    border: none;\n" +
"    color: Black;\n" +
"    padding: 8px 16px;\n" +
"    text-decoration: none;\n" +
"    margin: 4px 2px;\n" +
"    cursor: pointer;\n" +
" }\n" +
" input[type=submit] {\n" +
"   background-color:green;\n" +
"    border: none;\n" +
"    color: Black;\n" +
"    padding: 8px 16px;\n" +
"    text-decoration: none;\n" +
"    margin: 4px 2px;\n" +
"    cursor: pointer;\n" +
" }\n" +
"</style>\n" +
"<!-- Custom Theme files -->\n" +
"<script src=\"js3/jquery-1.12.0.min.js\"></script>\n" +
"<script src=\"js3/bootstrap.min.js\"></script>\n" +
"<!--animate-->\n" +
"<link href=\"css3/animate.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\">\n" +
"<script src=\"js3/wow.min.js\"></script>\n" +
"	<script>\n" +
"		 new WOW().init();\n" +
"	</script>\n" +
"<!--//end-animate-->\n" +
"</head>\n" +
"<body>\n" +
"<!-- top-header -->\n" +
"<div class=\"top-header\">\n" +
"	<div class=\"container\">\n" +
"		<ul class=\"tp-hd-lft wow fadeInLeft animated\" data-wow-delay=\".5s\">\n" +
"			<li class=\"prnt\"><a href=\"javascript:window.print()\">Print/SMS Ticket</a></li>\n" +
"				\n" +
"		</ul>\n" +
"		<ul class=\"tp-hd-rgt wow fadeInRight animated\" data-wow-delay=\".5s\"> \n" +
"			<li class=\"tol\">Toll Number : 123-4568790</li>				\n" +
"			<li><a href=\"b1.html\" >Log out</a></li> \n" +
"        </ul>\n" +
"		<div class=\"clearfix\"></div>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /top-header ---->\n" +
"<!--- header ---->\n" +
"<div class=\"header\">\n" +
"	<div class=\"container\">\n" +
"		<div class=\"logo wow fadeInDown animated\" data-wow-delay=\".5s\">\n" +
"			<a href=\"h1.java\">Home <span></span></a>	\n" +
"		</div>\n" +
"		<div class=\"bus wow fadeInUp animated\" data-wow-delay=\".5s\">\n" +

"           \n" +
"        </div>\n" +
"		<div class=\"lock fadeInDown animated\" data-wow-delay=\".5s\"> \n" +
"            <li><div class=\"securetxt\">SAFE &amp; SECURE<br> ONLINE PAYMENTS</div></li>\n" +
"			<div class=\"clearfix\"></div>\n" +
"		</div>\n" +
"		<div class=\"clearfix\"></div>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /header ---->\n" +
"<!--- footer-btm ---->\n" +
"<div class=\"footer-btm wow fadeInLeft animated\" data-wow-delay=\".5s\">\n" +
"	<div class=\"container\">\n" +
"	<div class=\"navigation\">\n" +
"			<nav class=\"navbar navbar-default\">\n" +
"				<!-- Brand and toggle get grouped for better mobile display -->\n" +
"				<div class=\"navbar-header\">\n" +
"				  <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\">\n" +
"					<span class=\"sr-only\">Toggle navigation</span>\n" +
"					<span class=\"icon-bar\"></span>\n" +
"					<span class=\"icon-bar\"></span>\n" +
"					<span class=\"icon-bar\"></span>\n" +
"				  </button>\n" +
"				</div>\n" +
"				<!-- Collect the nav links, forms, and other content for toggling -->\n" +
"				<div class=\"collapse navbar-collapse nav-wil\" id=\"bs-example-navbar-collapse-1\">\n" +
"					<nav class=\"cl-effect-1\">\n" +
"						<ul class=\"nav navbar-nav\">\n" +
"							<li><a href=\"about.html\">About</a></li>\n" +
"								<li><a href=\"privacy.html\">Privacy Policy</a></li>\n"+
"								<li><a href=\"terms.html\">Terms of Use</a></li>\n" +
								
"								<li>Need Help?<a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal3\"> / Write Us </a>  </li>\n" +
"								<div class=\"clearfix\"></div>\n" +
"						</ul>\n" +
"					</nav>\n" +
"				</div><!-- /.navbar-collapse -->	\n" +
"			</nav>\n" +
"		</div>\n" +
"		\n" +
"		<div class=\"clearfix\"></div>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /footer-btm ---->\n" +
"<!--- banner-1 ---->\n" +
"<div class=\"banner \">\n" +
"	<div class=\"container\">\n" +
"		<h1 class=\"wow zoomIn animated animated\" data-wow-delay=\".5s\" style=\"visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;\">Online Bus Booking System</h1>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /banner-1 ---->\n" +
"<!--- bus-tp ---->\n" +
"<div class=\"bus-tp\">\n" +
"	<div class=\"container\">\n" +
"		<p>Fare starts from : Rs. 300/-</p>\n" +
"		<h2>Buses from Durgapur to Kolkata or Karunamoyee</h2>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /bus-tp ---->\n" +
"<!--- bus-btm ---->\n" +
"<div class=\"bus-btm\">\n" +
"	\n" +
"</div>\n" +
"<!--- /bus-btm ---->\n" +
"<!--- bus-midd ---->\n" +
"       <table border=\"0\" align=\"center\">\n" +
"    <tr>\n" +
"         <th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Time</th>\n" +
"        <th>&nbsp;&nbsp;&nbsp;Fare</th>\n" +
"         <tr>\n" +
"              <form method=\"post\" action=\"s2 \"> \n" +
"                <td><input type=\"text\"   name=\"c2\" value=\"  7:30-10:00(2:30 hr)\" ></td><td><input type=\"text\"  name=\"r2\"  value=\"300/-\" ></td>\n" +
"          <td><input type=\"submit\" value=\"seat view\"></td>\n" +
"               </form></tr>\n" +
"          <tr>\n" +
"      <form method=\"post\" action=\"s2\">\n" +
"                <td><input type=\"text\"   name=\"c2\" value=\"  9:30-12:00(2:30 hr)\" ></td><td><input type=\"text\"  name=\"r2\"  value=\"300/-\" ></td>\n" +
"               <td><input type=\"submit\" value=\" seat view\"></td>\n" +
"               </form></tr>\n" +
"      <tr>\n" +
"      <form method=\"post\" action=\"s2\">\n" +
"              <td><input type=\"text\"   name=\"c2\" value=\"  12:00-14:30(2:30hr)\" ></td><td><input type=\"text\"  name=\"r2\"  value=\"300/-\" ></td>\n" +
"               <td><input type=\"submit\" value=\"seat view\"></td>\n" +
"               </form></tr>\n" +
"       <tr>\n" +
"      <form method=\"post\" action=\"s2\">\n" +
"                <td><input type=\"text\"   name=\"c2\" value=\"  14:30-17:00(2:30 hr)\" ></td><td><input type=\"text\"  name=\"r2\"  value=\"300/-\" ></td>\n" +
"               <td><input type=\"submit\" value=\"seat view\"></td>\n" +
"               </form></td></tr>\n" +
"        <tr>\n" +
"      <form method=\"post\" action=\"s2\">\n" +
"                 <td><input type=\"text\"   name=\"c2\" value=\"  17:00-19:30(2:30 hr)\" ></td><td><input type=\"text\"  name=\"r2\"  value=\"300/-\" ></td>\n" +
"               <td><input type=\"submit\" value=\"seat view\"></td>\n" +
"               </form></tr>\n" +
"        <tr>\n" +
"      <form method=\"post\" action=\"s2\">\n" +
"                <td><input type=\"text\"   name=\"c2\" value=\"  20:00-22:30(2:30 hr)\" ></td><td><input type=\"text\"  name=\"r2\"  value=\"300/-\" ></td>\n" +
"               <td><input type=\"submit\" value=\"seat view\"></td>\n" +
"               </form></tr>\n" +
"               \n" +
"         </table>\n" +
"\n" +
"                 \n" +
"<!--- /bus-midd ---->\n" +
"<!--- footer-top ---->\n" +
"<div class=\"footer-top\">\n" +
"	<div class=\"container\">\n" +
"		\n" +
"		<div class=\"col-md-6 footer-left wow fadeInRight animated\" data-wow-delay=\".5s\">\n" +
"			<h3>Bus Routes</h3>\n" +
"				<ul>\n" +
"					<li>Asansol-Durgapur </li>\n" +
"					<li>Asansol-Kolkata</li>\n" +
"					<li>Asansol-Karunamoyee</li>\n" +
"					<li>Durgapur-Dolkata</a></li>\n" +
"					<li>Durgapur-Karunamoyee</a></li>\n" +
"					<li>Burdwan-Kolkata</a></li>\n" +
"					<li>Burdwan-Karunamoyee</li>\n" +
"				</ul>\n" +
"		</div>\n" +
"		<div class=\"clearfix\"></div>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /footer-top ---->\n" +
"<!---copy-right ---->\n" +
"<div class=\"copy-right\">\n" +
"	<div class=\"container\">\n" +
"	\n" +
"		<div class=\"footer-social-icons wow fadeInDown animated animated\" data-wow-delay=\".5s\" style=\"visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;\">\n" +
"			<ul>\n" +
"				<li><a class=\"facebook\" href=\"#\"><span>Facebook</span></a></li>\n" +
"				<li><a class=\"twitter\" href=\"#\"><span>Twitter</span></a></li>\n" +
"				<li><a class=\"flickr\" href=\"#\"><span>Flickr</span></a></li>\n" +
"				<li><a class=\"googleplus\" href=\"#\"><span>Google+</span></a></li>\n" +
"				<li><a class=\"dribbble\" href=\"#\"><span>Dribbble</span></a></li>\n" +
"			</ul>\n" +
"		</div>\n" +
"		<p class=\"wow zoomIn animated animated\" data-wow-delay=\".5s\" style=\"visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;\">© 2016 Green Wheels . All Rights Reserved | Design by  <a href=\"http://w3layouts.com/\" target=\"_blank\">W3layouts</a> </p>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /copy-right ---->\n" +
"<!-- sign -->\n" +
"			<div class=\"modal fade\" id=\"myModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\">\n" +
"				<div class=\"modal-dialog\" role=\"document\">\n" +
"					<div class=\"modal-content\">\n" +
"						<div class=\"modal-header\">\n" +
"							<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>						\n" +
"						</div>\n" +
"							<section>\n" +
"								<div class=\"modal-body modal-spa\">\n" +
"									<div class=\"login-grids\">\n" +
"										<div class=\"login\">\n" +
"											<div class=\"login-left\">\n" +
"												<ul>\n" +
"													<li><a class=\"fb\" href=\"#\"><i></i>Sign in with Facebook</a></li>\n" +
"													<li><a class=\"goog\" href=\"#\"><i></i>Sign in with Google</a></li>\n" +
"													<li><a class=\"linkin\" href=\"#\"><i></i>Sign in with Linkedin</a></li>\n" +
"												</ul>\n" +
"											</div>\n" +
"											<div class=\"login-right\">\n" +
"												<form>\n" +
"													<h3>Create your account </h3>\n" +
"													<input type=\"text\" value=\"Name\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Name';}\" required=\"\">\n" +
"													<input type=\"text\" value=\"Mobile number\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Mobile number';}\" required=\"\">\n" +
"													<input type=\"text\" value=\"Email id\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Email id';}\" required=\"\">	\n" +
"													<input type=\"password\" value=\"Password\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Password';}\" required=\"\">	\n" +
"													<input type=\"submit\" value=\"CREATE ACCOUNT\">\n" +
"												</form>\n" +
"											</div>\n" +
"												<div class=\"clearfix\"></div>								\n" +
"										</div>\n" +
"											<p>By logging in you agree to our <a href=\"terms.html\">Terms and Conditions</a> and <a href=\"privacy.html\">Privacy Policy</a></p>\n" +
"									</div>\n" +
"								</div>\n" +
"							</section>\n" +
"					</div>\n" +
"				</div>\n" +
"			</div>\n" +
"<!-- //sign -->\n" +
"<!-- signin -->\n" +
"		<div class=\"modal fade\" id=\"myModal4\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\">\n" +
"				<div class=\"modal-dialog\" role=\"document\">\n" +
"					<div class=\"modal-content modal-info\">\n" +
"						<div class=\"modal-header\">\n" +
"							<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">×</span></button>						\n" +
"						</div>\n" +
"						<div class=\"modal-body modal-spa\">\n" +
"							<div class=\"login-grids\">\n" +
"								<div class=\"login\">\n" +
"									<div class=\"login-left\">\n" +
"										<ul>\n" +
"											<li><a class=\"fb\" href=\"#\"><i></i>Sign in with Facebook</a></li>\n" +
"											<li><a class=\"goog\" href=\"#\"><i></i>Sign in with Google</a></li>\n" +
"											<li><a class=\"linkin\" href=\"#\"><i></i>Sign in with Linkedin</a></li>\n" +
"										</ul>\n" +
"									</div>\n" +
"									<div class=\"login-right\">\n" +
"										<form>\n" +
"											<h3>Signin with your account </h3>\n" +
"											<input type=\"text\" value=\"Enter your mobile number or Email\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Enter your mobile number or Email';}\" required=\"\">	\n" +
"											<input type=\"password\" value=\"Password\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Password';}\" required=\"\">	\n" +
"											<h4><a href=\"#\">Forgot password</a></h4>\n" +
"											<div class=\"single-bottom\">\n" +
"												<input type=\"checkbox\" id=\"brand\" value=\"\">\n" +
"												<label for=\"brand\"><span></span>Remember Me.</label>\n" +
"											</div>\n" +
"											<input type=\"submit\" value=\"SIGNIN\">\n" +
"										</form>\n" +
"									</div>\n" +
"									<div class=\"clearfix\"></div>								\n" +
"								</div>\n" +
"								<p>By logging in you agree to our <a href=\"terms.html\">Terms and Conditions</a> and <a href=\"privacy.html\">Privacy Policy</a></p>\n" +
"							</div>\n" +
"						</div>\n" +
"					</div>\n" +
"				</div>\n" +
"			</div>\n" +
"<!-- //signin -->\n" +
"<!-- write us -->\n" +
"			<div class=\"modal fade\" id=\"myModal3\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\">\n" +
"				<div class=\"modal-dialog\" role=\"document\">\n" +
"					<div class=\"modal-content\">\n" +
"						<div class=\"modal-header\">\n" +
"							<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>						\n" +
"						</div>\n" +
"							<section>\n" +
"								<div class=\"modal-body modal-spa\">\n" +
"									<div class=\"writ\">\n" +
"										<h4>HOW CAN WE HELP YOU</h4>\n" +
"                                                                                                                                                                                                 <form method=\"post\" action=\"\">\n" +
"											<ul>\n" +
"												<li class=\"na-me\">\n" +
"													<input class=\"name\" type=\"text\" value=\"Name\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Name';}\" required=\"\">\n" +
"												</li>\n" +
"												<li class=\"na-me\">\n" +
"													<input class=\"Email\" type=\"text\" value=\"Email\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Email';}\" required=\"\">\n" +
"												</li>\n" +
"												<li class=\"na-me\">\n" +
"													<input class=\"number\" type=\"text\" value=\"Mobile Number\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Mobile Number';}\" required=\"\">\n" +
"												</li>\n" +
"												<li class=\"na-me\">\n" +
"													<select id=\"country\" onchange=\"change_country(this.value)\" class=\"frm-field required sect\">\n" +
"														<option value=\"null\">Select Issue</option> 		\n" +
"														<option value=\"null\">Booking Issues</option>\n" +
"														<option value=\"null\">Bus Cancellation</option>\n" +
"														<option value=\"null\">Refund</option>\n" +
"														<option value=\"null\">Wallet</option>														\n" +
"													</select>\n" +
"												</li>\n" +
"												<li class=\"na-me\">\n" +
"													<select id=\"country\" onchange=\"change_country(this.value)\" class=\"frm-field required sect\">\n" +
"														<option value=\"null\">Select Issue</option> 		\n" +
"														<option value=\"null\">Booking Issues</option>\n" +
"														<option value=\"null\">Bus Cancellation</option>\n" +
"														<option value=\"null\">Refund</option>\n" +
"														<option value=\"null\">Wallet</option>														\n" +
"													</select>\n" +
"												</li>\n" +
"												<li class=\"descrip\">\n" +
"													<input class=\"special\" type=\"text\" value=\"Write Description\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Write Description';}\" required=\"\">\n" +
"												</li>\n" +
"													<div class=\"clearfix\"></div>\n" +
"											</ul>\n" +
"											<div class=\"sub-bn\">\n" +
"												\n" +
"													<input type=\"submit\" value=\"submit\">\n" +
"												\n" +
"											</div>\n" +
"                                                                                                                                                                                      </form>\n" +
"									</div>\n" +
"								</div>\n" +
"							</section>\n" +
"					</div>\n" +
"				</div>\n" +
"			</div>\n" +
"<!-- //write us -->\n" +
"</body>\n" +
"</html>");
            }
          else
                if((na.equals("Burdwan") && na1.equals("Kolkata"))||(na.equals("Burdwan") && na1.equals("Karunamoyee")))
                {
                  pw1.println("<!--\n" +
"Author: W3layouts\n" +
"Author URL: http://w3layouts.com\n" +
"License: Creative Commons Attribution 3.0 Unported\n" +
"License URL: http://creativecommons.org/licenses/by/3.0/\n" +
"-->\n" +
"<!DOCTYPE HTML>\n" +
"<html>\n" +
"<head>\n" +
"<title>Green Wheels a Travel Category Flat Bootstrap Responsive Website Template | Bus :: w3layouts</title>\n" +
"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
"<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n" +
"<meta name=\"keywords\" content=\"Green Wheels Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, \n" +
"Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design\" />\n" +
"<script type=\"applijewelleryion/x-javascript\"> addEventListener(\"load\", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>\n" +
"<link href=\"css3/bootstrap.css\" rel='stylesheet' type='text/css' />\n" +
"<link href=\"css3/style.css\" rel='stylesheet' type='text/css' />\n" +
"<link href='//fonts3.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>\n" +
"<link href='//fonts3.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>\n" +
"<link href='//fonts3.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>\n" +
"<link href=\"css3/font-awesome.css\" rel=\"stylesheet\">\n" +
"<style>\n" +
"     div.banner{\n" +
"    width: 100%;\n" +
"    height: 100%;\n" +
"    background-image: url('banner.jpg');\n" +
"    background-repeat: no-repeat;\n" +
"     }\n" +
"     input[type=text] {\n" +
"   background-color:white;\n" +
"    border: none;\n" +
"    color: Black;\n" +
"    padding: 8px 16px;\n" +
"    text-decoration: none;\n" +
"    margin: 4px 2px;\n" +
"    cursor: pointer;\n" +
" }\n" +
" input[type=submit] {\n" +
"   background-color:green;\n" +
"    border: none;\n" +
"    color: Black;\n" +
"    padding: 8px 16px;\n" +
"    text-decoration: none;\n" +
"    margin: 4px 2px;\n" +
"    cursor: pointer;\n" +
" }\n" +
"</style>\n" +
"<!-- Custom Theme files -->\n" +
"<script src=\"js3/jquery-1.12.0.min.js\"></script>\n" +
"<script src=\"js3/bootstrap.min.js\"></script>\n" +
"<!--animate-->\n" +
"<link href=\"css3/animate.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\">\n" +
"<script src=\"js3/wow.min.js\"></script>\n" +
"	<script>\n" +
"		 new WOW().init();\n" +
"	</script>\n" +
"<!--//end-animate-->\n" +
"</head>\n" +
"<body>\n" +
"<!-- top-header -->\n" +
"<div class=\"top-header\">\n" +
"	<div class=\"container\">\n" +
"		<ul class=\"tp-hd-lft wow fadeInLeft animated\" data-wow-delay=\".5s\">\n" +
"			<li class=\"prnt\"><a href=\"javascript:window.print()\">Print/SMS Ticket</a></li>\n" +
"				\n" +
"		</ul>\n" +
"		<ul class=\"tp-hd-rgt wow fadeInRight animated\" data-wow-delay=\".5s\"> \n" +
"			<li class=\"tol\">Toll Number : 123-4568790</li>				\n" +
"			<li><a href=\"b1.html\">Log out</a></li> \n" +
"        </ul>\n" +
"		<div class=\"clearfix\"></div>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /top-header ---->\n" +
"<!--- header ---->\n" +
"<div class=\"header\">\n" +
"	<div class=\"container\">\n" +
"		<div class=\"logo wow fadeInDown animated\" data-wow-delay=\".5s\">\n" +
"			<a href=\"h1.java\">Home <span></span></a>	\n" +
"		</div>\n" +
"		<div class=\"bus wow fadeInUp animated\" data-wow-delay=\".5s\">\n" +          
"           \n" +
"        </div>\n" +
"		<div class=\"lock fadeInDown animated\" data-wow-delay=\".5s\"> \n" +
"            <li><div class=\"securetxt\">SAFE &amp; SECURE<br> ONLINE PAYMENTS</div></li>\n" +
"			<div class=\"clearfix\"></div>\n" +
"		</div>\n" +
"		<div class=\"clearfix\"></div>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /header ---->\n" +
"<!--- footer-btm ---->\n" +
"<div class=\"footer-btm wow fadeInLeft animated\" data-wow-delay=\".5s\">\n" +
"	<div class=\"container\">\n" +
"	<div class=\"navigation\">\n" +
"			<nav class=\"navbar navbar-default\">\n" +
"				<!-- Brand and toggle get grouped for better mobile display -->\n" +
"				<div class=\"navbar-header\">\n" +
"				  <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\">\n" +
"					<span class=\"sr-only\">Toggle navigation</span>\n" +
"					<span class=\"icon-bar\"></span>\n" +
"					<span class=\"icon-bar\"></span>\n" +
"					<span class=\"icon-bar\"></span>\n" +
"				  </button>\n" +
"				</div>\n" +
"				<!-- Collect the nav links, forms, and other content for toggling -->\n" +
"				<div class=\"collapse navbar-collapse nav-wil\" id=\"bs-example-navbar-collapse-1\">\n" +
"					<nav class=\"cl-effect-1\">\n" +
"						<ul class=\"nav navbar-nav\">\n" +
"							<li><a href=\"about.html\">About</a></li>\n" +
"								<li><a href=\"privacy.html\">Privacy Policy</a></li>\n" +
								
"								<li><a href=\"terms.html\">Terms of Use</a></li>\n" +
								
"								<li>Need Help?<a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal3\"> / Write Us </a>  </li>\n" +
"								<div class=\"clearfix\"></div>\n" +
"						</ul>\n" +
"					</nav>\n" +
"				</div><!-- /.navbar-collapse -->	\n" +
"			</nav>\n" +
"		</div>\n" +
"		\n" +
"		<div class=\"clearfix\"></div>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /footer-btm ---->\n" +
"<!--- banner-1 ---->\n" +
"<div class=\"banner \">\n" +
"	<div class=\"container\">\n" +
"		<h1 class=\"wow zoomIn animated animated\" data-wow-delay=\".5s\" style=\"visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;\">Online Bus Booking System</h1>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /banner-1 ---->\n" +
"<!--- bus-tp ---->\n" +
"<div class=\"bus-tp\">\n" +
"	<div class=\"container\">\n" +
"		<p>Fare starts from : Rs. 200/-</p>\n" +
"		<h2>Buses from Burdwan to Kolkata or Karunamoyee</h2>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /bus-tp ---->\n" +
"<!--- bus-btm ---->\n" +
"<div class=\"bus-btm\">\n" +
"	\n" +
"</div>\n" +
"<!--- /bus-btm ---->\n" +
"<!--- bus-midd ---->\n" +
"       <table border=\"0\" align=\"center\">\n" +
"    <tr>\n" +
"         <th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Time</th>\n" +
"        <th>&nbsp;&nbsp;&nbsp;Fare</th>\n" +
"         <tr>\n" +
"              <form method=\"post\" action=\"s3 \"> \n" +
"                <td><input type=\"text\"   name=\"c3\" value=\"  6:00-8:00(2 hr)\" ></td><td><input type=\"text\"  name=\"r3\"  value=\"200/-\" ></td>\n" +
"          <td><input type=\"submit\" value=\"seat view\"></td>\n" +
"               </form></tr>\n" +
"          <tr>\n" +
"      <form method=\"post\" action=\"s3\">\n" +
"                <td><input type=\"text\"   name=\"c3\" value=\"  8:00-10:00(2 hr)\" ></td><td><input type=\"text\"  name=\"r3\"  value=\"200/-\" ></td>\n" +
"               <td><input type=\"submit\" value=\"seat view\"></td>\n" +
"               </form></tr>\n" +
"      <tr>\n" +
"      <form method=\"post\" action=\"s3\">\n" +
"              <td><input type=\"text\"   name=\"c3\" value=\"  11:00-13:00(2 hr)\" ></td><td><input type=\"text\"  name=\"r3\"  value=\"200/-\" ></td>\n" +
"               <td><input type=\"submit\" value=\"seat view\"></td>\n" +
"               </form></tr>\n" +
"       <tr>\n" +
"      <form method=\"post\" action=\"s3\">\n" +
"                <td><input type=\"text\"   name=\"c3\" value=\"  13:00-15:00(2 hr)\" ></td><td><input type=\"text\"  name=\"r3\"  value=\"200/-\" ></td>\n" +
"               <td><input type=\"submit\" value=\"seat view\"></td>\n" +
"               </form></td></tr>\n" +
"        <tr>\n" +
"      <form method=\"post\" action=\"s3\">\n" +
"                 <td><input type=\"text\"   name=\"c3\" value=\"  15:00-17:00(2 hr)\" ></td><td><input type=\"text\"  name=\"r3\"  value=\"200/-\" ></td>\n" +
"               <td><input type=\"submit\" value=\"seat view\"></td>\n" +
"               </form></tr>\n" +
"        <tr>\n" +
"      <form method=\"post\" action=\"s3\">\n" +
"                <td><input type=\"text\"   name=\"c3\" value=\"  18:00-20:00(2 hr)\" ></td><td><input type=\"text\"  name=\"r3\"  value=\"200/-\" ></td>\n" +
"               <td><input type=\"submit\" value=\"seat view\"></td>\n" +
"               </form></tr>\n" +
"               \n" +
"         </table>\n" +
"\n" +
"                 \n" +
"<!--- /bus-midd ---->\n" +
"<!--- footer-top ---->\n" +
"<div class=\"footer-top\">\n" +
"	<div class=\"container\">\n" +
"		\n" +
"		<div class=\"col-md-6 footer-left wow fadeInRight animated\" data-wow-delay=\".5s\">\n" +
"			<h3>Bus Routes</h3>\n" +
"				<ul>\n" +
"					<li>Asansol-Durgapur </li>\n" +
"					<li>Asansol-Kolkata</li>\n" +
"					<li>Asansol-Karunamoyee</li>\n" +
"					<li>Durgapur-Kolkata</a></li>\n" +
"					<li>Durgapur-Karunamoyee</a></li>\n" +
"					<li>Burdwan-Kolkata</a></li>\n" +
"					<li>Burdwan-Karunamoyee</li>\n" +
"				</ul>\n" +
"		</div>\n" +
"		<div class=\"clearfix\"></div>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /footer-top ---->\n" +
"<!---copy-right ---->\n" +
"<div class=\"copy-right\">\n" +
"	<div class=\"container\">\n" +
"	\n" +
"		<div class=\"footer-social-icons wow fadeInDown animated animated\" data-wow-delay=\".5s\" style=\"visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;\">\n" +
"			<ul>\n" +
"				<li><a class=\"facebook\" href=\"#\"><span>Facebook</span></a></li>\n" +
"				<li><a class=\"twitter\" href=\"#\"><span>Twitter</span></a></li>\n" +
"				<li><a class=\"flickr\" href=\"#\"><span>Flickr</span></a></li>\n" +
"				<li><a class=\"googleplus\" href=\"#\"><span>Google+</span></a></li>\n" +
"				<li><a class=\"dribbble\" href=\"#\"><span>Dribbble</span></a></li>\n" +
"			</ul>\n" +
"		</div>\n" +
"		<p class=\"wow zoomIn animated animated\" data-wow-delay=\".5s\" style=\"visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;\">© 2016 Green Wheels . All Rights Reserved | Design by  <a href=\"http://w3layouts.com/\" target=\"_blank\">W3layouts</a> </p>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /copy-right ---->\n" +
"<!-- sign -->\n" +
"			<div class=\"modal fade\" id=\"myModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\">\n" +
"				<div class=\"modal-dialog\" role=\"document\">\n" +
"					<div class=\"modal-content\">\n" +
"						<div class=\"modal-header\">\n" +
"							<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>						\n" +
"						</div>\n" +
"							<section>\n" +
"								<div class=\"modal-body modal-spa\">\n" +
"									<div class=\"login-grids\">\n" +
"										<div class=\"login\">\n" +
"											<div class=\"login-left\">\n" +
"												<ul>\n" +
"													<li><a class=\"fb\" href=\"#\"><i></i>Sign in with Facebook</a></li>\n" +
"													<li><a class=\"goog\" href=\"#\"><i></i>Sign in with Google</a></li>\n" +
"													<li><a class=\"linkin\" href=\"#\"><i></i>Sign in with Linkedin</a></li>\n" +
"												</ul>\n" +
"											</div>\n" +
"											<div class=\"login-right\">\n" +
"												<form>\n" +
"													<h3>Create your account </h3>\n" +
"													<input type=\"text\" value=\"Name\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Name';}\" required=\"\">\n" +
"													<input type=\"text\" value=\"Mobile number\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Mobile number';}\" required=\"\">\n" +
"													<input type=\"text\" value=\"Email id\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Email id';}\" required=\"\">	\n" +
"													<input type=\"password\" value=\"Password\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Password';}\" required=\"\">	\n" +
"													<input type=\"submit\" value=\"CREATE ACCOUNT\">\n" +
"												</form>\n" +
"											</div>\n" +
"												<div class=\"clearfix\"></div>								\n" +
"										</div>\n" +
"											<p>By logging in you agree to our <a href=\"terms.html\">Terms and Conditions</a> and <a href=\"privacy.html\">Privacy Policy</a></p>\n" +
"									</div>\n" +
"								</div>\n" +
"							</section>\n" +
"					</div>\n" +
"				</div>\n" +
"			</div>\n" +
"<!-- //sign -->\n" +
"<!-- signin -->\n" +
"		<div class=\"modal fade\" id=\"myModal4\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\">\n" +
"				<div class=\"modal-dialog\" role=\"document\">\n" +
"					<div class=\"modal-content modal-info\">\n" +
"						<div class=\"modal-header\">\n" +
"							<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">×</span></button>						\n" +
"						</div>\n" +
"						<div class=\"modal-body modal-spa\">\n" +
"							<div class=\"login-grids\">\n" +
"								<div class=\"login\">\n" +
"									<div class=\"login-left\">\n" +
"										<ul>\n" +
"											<li><a class=\"fb\" href=\"#\"><i></i>Sign in with Facebook</a></li>\n" +
"											<li><a class=\"goog\" href=\"#\"><i></i>Sign in with Google</a></li>\n" +
"											<li><a class=\"linkin\" href=\"#\"><i></i>Sign in with Linkedin</a></li>\n" +
"										</ul>\n" +
"									</div>\n" +
"									<div class=\"login-right\">\n" +
"										<form>\n" +
"											<h3>Signin with your account </h3>\n" +
"											<input type=\"text\" value=\"Enter your mobile number or Email\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Enter your mobile number or Email';}\" required=\"\">	\n" +
"											<input type=\"password\" value=\"Password\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Password';}\" required=\"\">	\n" +
"											<h4><a href=\"#\">Forgot password</a></h4>\n" +
"											<div class=\"single-bottom\">\n" +
"												<input type=\"checkbox\" id=\"brand\" value=\"\">\n" +
"												<label for=\"brand\"><span></span>Remember Me.</label>\n" +
"											</div>\n" +
"											<input type=\"submit\" value=\"SIGNIN\">\n" +
"										</form>\n" +
"									</div>\n" +
"									<div class=\"clearfix\"></div>								\n" +
"								</div>\n" +
"								<p>By logging in you agree to our <a href=\"terms.html\">Terms and Conditions</a> and <a href=\"privacy.html\">Privacy Policy</a></p>\n" +
"							</div>\n" +
"						</div>\n" +
"					</div>\n" +
"				</div>\n" +
"			</div>\n" +
"<!-- //signin -->\n" +
"<!-- write us -->\n" +
"			<div class=\"modal fade\" id=\"myModal3\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\">\n" +
"				<div class=\"modal-dialog\" role=\"document\">\n" +
"					<div class=\"modal-content\">\n" +
"						<div class=\"modal-header\">\n" +
"							<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>						\n" +
"						</div>\n" +
"							<section>\n" +
"								<div class=\"modal-body modal-spa\">\n" +
"									<div class=\"writ\">\n" +
"										<h4>HOW CAN WE HELP YOU</h4>\n" +
"                                                                                                                                                                                                 <form method=\"post\" action=\"\">\n" +
"											<ul>\n" +
"												<li class=\"na-me\">\n" +
"													<input class=\"name\" type=\"text\" value=\"Name\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Name';}\" required=\"\">\n" +
"												</li>\n" +
"												<li class=\"na-me\">\n" +
"													<input class=\"Email\" type=\"text\" value=\"Email\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Email';}\" required=\"\">\n" +
"												</li>\n" +
"												<li class=\"na-me\">\n" +
"													<input class=\"number\" type=\"text\" value=\"Mobile Number\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Mobile Number';}\" required=\"\">\n" +
"												</li>\n" +
"												<li class=\"na-me\">\n" +
"													<select id=\"country\" onchange=\"change_country(this.value)\" class=\"frm-field required sect\">\n" +
"														<option value=\"null\">Select Issue</option> 		\n" +
"														<option value=\"null\">Booking Issues</option>\n" +
"														<option value=\"null\">Bus Cancellation</option>\n" +
"														<option value=\"null\">Refund</option>\n" +
"														<option value=\"null\">Wallet</option>														\n" +
"													</select>\n" +
"												</li>\n" +
"												<li class=\"na-me\">\n" +
"													<select id=\"country\" onchange=\"change_country(this.value)\" class=\"frm-field required sect\">\n" +
"														<option value=\"null\">Select Issue</option> 		\n" +
"														<option value=\"null\">Booking Issues</option>\n" +
"														<option value=\"null\">Bus Cancellation</option>\n" +
"														<option value=\"null\">Refund</option>\n" +
"														<option value=\"null\">Wallet</option>														\n" +
"													</select>\n" +
"												</li>\n" +
"												<li class=\"descrip\">\n" +
"													<input class=\"special\" type=\"text\" value=\"Write Description\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Write Description';}\" required=\"\">\n" +
"												</li>\n" +
"													<div class=\"clearfix\"></div>\n" +
"											</ul>\n" +
"											<div class=\"sub-bn\">\n" +
"												\n" +
"													<input type=\"submit\" value=\"submit\">\n" +
"												\n" +
"											</div>\n" +
"                                                                                                                                                                                      </form>\n" +
"									</div>\n" +
"								</div>\n" +
"							</section>\n" +
"					</div>\n" +
"				</div>\n" +
"			</div>\n" +
"<!-- //write us -->\n" +
"</body>\n" +
"</html>");  
                }   
            else
                if(na.equals("Asansol") && na1.equals("Durgapur"))
                {
                  pw1.println("<!--\n" +
"Author: W3layouts\n" +
"Author URL: http://w3layouts.com\n" +
"License: Creative Commons Attribution 3.0 Unported\n" +
"License URL: http://creativecommons.org/licenses/by/3.0/\n" +
"-->\n" +
"<!DOCTYPE HTML>\n" +
"<html>\n" +
"<head>\n" +
"<title>Green Wheels a Travel Category Flat Bootstrap Responsive Website Template | Bus :: w3layouts</title>\n" +
"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
"<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n" +
"<meta name=\"keywords\" content=\"Green Wheels Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, \n" +
"Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design\" />\n" +
"<script type=\"applijewelleryion/x-javascript\"> addEventListener(\"load\", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>\n" +
"<link href=\"css3/bootstrap.css\" rel='stylesheet' type='text/css' />\n" +
"<link href=\"css3/style.css\" rel='stylesheet' type='text/css' />\n" +
"<link href='//fonts3.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>\n" +
"<link href='//fonts3.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>\n" +
"<link href='//fonts3.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>\n" +
"<link href=\"css3/font-awesome.css\" rel=\"stylesheet\">\n" +
"<style>\n" +
"     div.banner{\n" +
"    width: 100%;\n" +
"    height: 100%;\n" +
"    background-image: url('banner.jpg');\n" +
"    background-repeat: no-repeat;\n" +
"     }\n" +
"     input[type=text] {\n" +
"   background-color:white;\n" +
"    border: none;\n" +
"    color: Black;\n" +
"    padding: 8px 16px;\n" +
"    text-decoration: none;\n" +
"    margin: 4px 2px;\n" +
"    cursor: pointer;\n" +
" }\n" +
" input[type=submit] {\n" +
"   background-color:green;\n" +
"    border: none;\n" +
"    color: Black;\n" +
"    padding: 8px 16px;\n" +
"    text-decoration: none;\n" +
"    margin: 4px 2px;\n" +
"    cursor: pointer;\n" +
" }\n" +
"</style>\n" +
"<!-- Custom Theme files -->\n" +
"<script src=\"js3/jquery-1.12.0.min.js\"></script>\n" +
"<script src=\"js3/bootstrap.min.js\"></script>\n" +
"<!--animate-->\n" +
"<link href=\"css3/animate.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\">\n" +
"<script src=\"js3/wow.min.js\"></script>\n" +
"	<script>\n" +
"		 new WOW().init();\n" +
"	</script>\n" +
"<!--//end-animate-->\n" +
"</head>\n" +
"<body>\n" +
"<!-- top-header -->\n" +
"<div class=\"top-header\">\n" +
"	<div class=\"container\">\n" +
"		<ul class=\"tp-hd-lft wow fadeInLeft animated\" data-wow-delay=\".5s\">\n" +
"			<li class=\"prnt\"><a href=\"javascript:window.print()\">Print/SMS Ticket</a></li>\n" +
"				\n" +
"		</ul>\n" +
"		<ul class=\"tp-hd-rgt wow fadeInRight animated\" data-wow-delay=\".5s\"> \n" +
"			<li class=\"tol\">Toll Number : 123-4568790</li>				\n" +
"			<li><a href=\"b1.html\">Log out</a></li> \n" +
"        </ul>\n" +
"		<div class=\"clearfix\"></div>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /top-header ---->\n" +
"<!--- header ---->\n" +
"<div class=\"header\">\n" +
"	<div class=\"container\">\n" +
"		<div class=\"logo wow fadeInDown animated\" data-wow-delay=\".5s\">\n" +
"			<a href=\"b1.html\">Home <span></span></a>	\n" +
"		</div>\n" +
"		<div class=\"bus wow fadeInUp animated\" data-wow-delay=\".5s\">\n" +         
"           \n" +
"        </div>\n" +
"		<div class=\"lock fadeInDown animated\" data-wow-delay=\".5s\"> \n" +
"            <li><div class=\"securetxt\">SAFE &amp; SECURE<br> ONLINE PAYMENTS</div></li>\n" +
"			<div class=\"clearfix\"></div>\n" +
"		</div>\n" +
"		<div class=\"clearfix\"></div>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /header ---->\n" +
"<!--- footer-btm ---->\n" +
"<div class=\"footer-btm wow fadeInLeft animated\" data-wow-delay=\".5s\">\n" +
"	<div class=\"container\">\n" +
"	<div class=\"navigation\">\n" +
"			<nav class=\"navbar navbar-default\">\n" +
"				<!-- Brand and toggle get grouped for better mobile display -->\n" +
"				<div class=\"navbar-header\">\n" +
"				  <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\">\n" +
"					<span class=\"sr-only\">Toggle navigation</span>\n" +
"					<span class=\"icon-bar\"></span>\n" +
"					<span class=\"icon-bar\"></span>\n" +
"					<span class=\"icon-bar\"></span>\n" +
"				  </button>\n" +
"				</div>\n" +
"				<!-- Collect the nav links, forms, and other content for toggling -->\n" +
"				<div class=\"collapse navbar-collapse nav-wil\" id=\"bs-example-navbar-collapse-1\">\n" +
"					<nav class=\"cl-effect-1\">\n" +
"						<ul class=\"nav navbar-nav\">\n" +
"							<li><a href=\"about.html\">About</a></li>\n" +
"								<li><a href=\"privacy.html\">Privacy Policy</a></li>\n" +
								
"								<li><a href=\"terms.html\">Terms of Use</a></li>\n" +
								
"								<li>Need Help?<a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal3\"> / Write Us </a>  </li>\n" +
"								<div class=\"clearfix\"></div>\n" +
"						</ul>\n" +
"					</nav>\n" +
"				</div><!-- /.navbar-collapse -->	\n" +
"			</nav>\n" +
"		</div>\n" +
"		\n" +
"		<div class=\"clearfix\"></div>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /footer-btm ---->\n" +
"<!--- banner-1 ---->\n" +
"<div class=\"banner\">\n" +
"	<div class=\"container\">\n" +
"		<h1 class=\"wow zoomIn animated animated\" data-wow-delay=\".5s\" style=\"visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;\">Online Bus Booking System</h1>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /banner-1 ---->\n" +
"<!--- bus-tp ---->\n" +
"<div class=\"bus-tp\">\n" +
"	<div class=\"container\">\n" +
"		<p>Fare starts from : Rs. 100/-</p>\n" +
"		<h2>Buses from Asansol to Durgapur</h2>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /bus-tp ---->\n" +
"<!--- bus-btm ---->\n" +
"<div class=\"bus-btm\">\n" +
"	\n" +
"</div>\n" +
"<!--- /bus-btm ---->\n" +
"<!--- bus-midd ---->\n" +
"       <table border=\"0\" align=\"center\">\n" +
"    <tr>\n" +
"         <th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Time</th>\n" +
"        <th>&nbsp;&nbsp;&nbsp;Fare</th>\n" +
"         <tr>\n" +
"              <form method=\"post\" action=\"s4 \"> \n" +
"                <td><input type=\"text\"   name=\"c4\" value=\"  6:00-7:00(1 hr)\" ></td><td><input type=\"text\"  name=\"r4\"  value=\"100/-\" ></td>\n" +
"          <td><input type=\"submit\" value=\"seat view\"></td>\n" +
"               </form></tr>\n" +
"          <tr>\n" +
"      <form method=\"post\" action=\"s4\">\n" +
"                <td><input type=\"text\"   name=\"c4\" value=\"  8:00-9:00(1 hr)\" ></td><td><input type=\"text\"  name=\"r4\"  value=\"100/-\" ></td>\n" +
"               <td><input type=\"submit\" value=\" seat view\"></td>\n" +
"               </form></tr>\n" +
"      <tr>\n" +
"      <form method=\"post\" action=\"s4\">\n" +
"              <td><input type=\"text\"   name=\"c4\" value=\"  11:00-12:00(1 hr)\" ></td><td><input type=\"text\"  name=\"r4\"  value=\"100/-\" ></td>\n" +
"               <td><input type=\"submit\" value=\"seat view\"></td>\n" +
"               </form></tr>\n" +
"       <tr>\n" +
"      <form method=\"post\" action=\"s4\">\n" +
"                <td><input type=\"text\"   name=\"c4\" value=\"  13:00-14:00(1 hr)\" ></td><td><input type=\"text\"  name=\"r4\"  value=\"100/-\" ></td>\n" +
"               <td><input type=\"submit\" value=\"seat view\"></td>\n" +
"               </form></td></tr>\n" +
"        <tr>\n" +
"      <form method=\"post\" action=\"s4\">\n" +
"                 <td><input type=\"text\"   name=\"c4\" value=\"  15:00-16:00(1 hr)\" ></td><td><input type=\"text\"  name=\"r4\"  value=\"100/-\" ></td>\n" +
"               <td><input type=\"submit\" value=\"seat view\"></td>\n" +
"               </form></tr>\n" +
"        <tr>\n" +
"      <form method=\"post\" action=\"s4\">\n" +
"                <td><input type=\"text\"   name=\"c4\" value=\"  18:00-19:00(1 hr)\" ></td><td><input type=\"text\"  name=\"r4\"  value=\"100/-\" ></td>\n" +
"               <td><input type=\"submit\" value=\"seat view\"></td>\n" +
"               </form></tr>\n" +
"               \n" +
"         </table>\n" +
"\n" +
"                 \n" +
"<!--- /bus-midd ---->\n" +
"<!--- footer-top ---->\n" +
"<div class=\"footer-top\">\n" +
"	<div class=\"container\">\n" +
"		\n" +
"		<div class=\"col-md-6 footer-left wow fadeInRight animated\" data-wow-delay=\".5s\">\n" +
"			<h3>Bus Routes</h3>\n" +
"				<ul>\n" +
"					<li>Asansol-Durgapur </li>\n" +
"					<li>Asansol-Kolkata</li>\n" +
"					<li>Asansol-Karunamoyee</li>\n" +
"					<li>Durgapur-Kolkata</a></li>\n" +
"					<li>Durgapur-Karunamoyee</a></li>\n" +
"					<li>Burdwan-Kolkata</a></li>\n" +
"					<li>Burdwan-Karunamoyee</li>\n" +
"				</ul>\n" +
"		</div>\n" +
"		<div class=\"clearfix\"></div>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /footer-top ---->\n" +
"<!---copy-right ---->\n" +
"<div class=\"copy-right\">\n" +
"	<div class=\"container\">\n" +
"	\n" +
"		<div class=\"footer-social-icons wow fadeInDown animated animated\" data-wow-delay=\".5s\" style=\"visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;\">\n" +
"			<ul>\n" +
"				<li><a class=\"facebook\" href=\"#\"><span>Facebook</span></a></li>\n" +
"				<li><a class=\"twitter\" href=\"#\"><span>Twitter</span></a></li>\n" +
"				<li><a class=\"flickr\" href=\"#\"><span>Flickr</span></a></li>\n" +
"				<li><a class=\"googleplus\" href=\"#\"><span>Google+</span></a></li>\n" +
"				<li><a class=\"dribbble\" href=\"#\"><span>Dribbble</span></a></li>\n" +
"			</ul>\n" +
"		</div>\n" +
"		<p class=\"wow zoomIn animated animated\" data-wow-delay=\".5s\" style=\"visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;\">© 2016 Green Wheels . All Rights Reserved | Design by  <a href=\"http://w3layouts.com/\" target=\"_blank\">W3layouts</a> </p>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /copy-right ---->\n" +
"<!-- sign -->\n" +
"			\n" +
"<!-- //signin -->\n" +
"<!-- write us -->\n" +
"			<div class=\"modal fade\" id=\"myModal3\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\">\n" +
"				<div class=\"modal-dialog\" role=\"document\">\n" +
"					<div class=\"modal-content\">\n" +
"						<div class=\"modal-header\">\n" +
"							<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>						\n" +
"						</div>\n" +
"							<section>\n" +
"								<div class=\"modal-body modal-spa\">\n" +
"									<div class=\"writ\">\n" +
"										<h4>HOW CAN WE HELP YOU</h4>\n" +
"                                                                                                <form method=\"post\" action=\"a4\">\n" +
"											<ul>\n" +
"												<li class=\"na-me\">\n" +
"													<input class=\"name\" type=\"text\" name=\"y1\" value=\"Name\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Name';}\" required=\"\">\n" +
"												</li>\n" +
"												<li class=\"na-me\">\n" +
"													<input class=\"Email\" type=\"text\" name=\"y2\" value=\"Email\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Email';}\" required=\"\">\n" +
"												</li>\n" +
"												<li class=\"na-me\">\n" +
"													<input class=\"number\" type=\"text\" name=\"y3\" value=\"Mobile Number\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Mobile Number';}\" required=\"\">\n" +
"												</li>\n" +
"												<li class=\"na-me\">\n" +
"													<select id=\"country\" name=\"y4\" onchange=\"change_country(this.value)\" class=\"frm-field required sect\">\n" +
"														<option value=\"null\">Select Issue</option> 		\n" +
"														<option value=\"null\">Booking Issues</option>\n" +
"														<option value=\"null\">Bus Cancellation</option>\n" +
"														<option value=\"null\">Refund</option>\n" +
"														<option value=\"null\">Wallet</option>														\n" +
"													</select>\n" +
"												</li>\n" +
												
"												<li class=\"descrip\">\n" +
"													<input class=\"special\" type=\"text\" name=\"y5\" value=\"Write Description\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Write Description';}\" required=\"\">\n" +
"												</li>\n" +
"													<div class=\"clearfix\"></div>\n" +
"											</ul>\n" +
"											<div class=\"sub-bn\">\n" +
"												\n" +
"													<input type=\"submit\" value=\"submit\">\n" +
"												\n" +
"											</div>\n" +
"                                                                                                                                                                                      </form>\n" +
"									</div>\n" +
"								</div>\n" +
"							</section>\n" +
"					</div>\n" +
"				</div>\n" +
"			</div>\n" +
"<!-- //write us -->\n" +
"</body>\n" +
"</html>");
                 }     
               }
               else
               {
                  pw1.println("insert unsuccess");
                    
               }
               con.close();
           }
              catch(Exception e)
              {
                  pw1.println(e);
              }
   
  }
} 