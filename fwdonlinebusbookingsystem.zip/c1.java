import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import javax.servlet.*;
import javax.servlet.http.*;



public class c1 extends HttpServlet
{
  public void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
  {
      res.setContentType("text/html");
      PrintWriter pw1=res.getWriter();
      String nq=req.getParameter("q1");
      String nq1=req.getParameter("q2");
     
      try
         {
            
              Class.forName("oracle.jdbc.driver.OracleDriver");
                 //registering type4 driver
               Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","ujjwal3","das1");
               Statement stmt=con.createStatement();
               String q1="select * from ud where name='"+nq+"'and password='"+nq1+"'";
               ResultSet rs=stmt.executeQuery(q1);
               if(rs.next())
               {
                   //pw1.println("The name is: "+rs.getString(1));
                   //pw1.println("The password is: "+rs.getString(2));
                   
                   pw1.println("<!--\n" +
"Author: W3layouts\n" +
"Author URL: http://w3layouts.com\n" +
"License: Creative Commons Attribution 3.0 Unported\n" +
"License URL: http://creativecommons.org/licenses/by/3.0/\n" +
"-->\n" +
"<!DOCTYPE HTML>\n" +
"<html>\n" +
"<head>\n" +
"<title>Green Wheels a Travel Category Flat Bootstrap Responsive Website Template | Agent Registration :: w3layouts</title>\n" +
"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
"<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n" +
"<meta name=\"keywords\" content=\"Green Wheels Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, \n" +
"Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design\" />\n" +
"<script type=\"applijewelleryion/x-javascript\"> addEventListener(\"load\", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>\n" +
"<link href=\"css3/bootstrap.css\" rel='stylesheet' type='text/css' />\n" +
"<link href=\"css3/style.css\" rel='stylesheet' type='text/css' />\n" +
"<link href='//fonts3.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>\n" +
"<link href='//fonts3.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>\n" +
"<link href='//fonts3.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>\n" +
"<link href=\"css3/font-awesome.css\" rel=\"stylesheet\">\n" +
"<style>\n" +
"     div.banner{\n" +
"    width: 100%;\n" +
"    height: 100%;\n" +
"    background-image: url('banner.jpg');\n" +
"    background-repeat: no-repeat;\n" +
"     }\n" +
"   \n" +
"</style>\n" +
"<!-- Custom Theme files -->\n" +
"<script src=\"js3/jquery-1.12.0.min.js\"></script>\n" +
"<script src=\"js3/bootstrap.min.js\"></script>\n" +
"<!--animate-->\n" +
"<link href=\"css3/animate.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\">\n" +
"<script src=\"js3/wow.min.js\"></script>\n" +
"	<script>\n" +
"		 new WOW().init();\n" +
"	</script>\n" +
"<!--//end-animate-->\n" +
"</head>\n" +
"<body>\n" +
"<!-- top-header -->\n" +
"<div class=\"top-header\">\n" +
"	<div class=\"container\">\n" +
"		<ul class=\"tp-hd-lft wow fadeInLeft animated\" data-wow-delay=\".5s\">\n" +
"			<li class=\"prnt\"><a href=\"javascript:window.print()\">Print/SMS Ticket</a></li>\n" +
"				\n" +
"		</ul>\n" +
"		<ul class=\"tp-hd-rgt wow fadeInRight animated\" data-wow-delay=\".5s\"> \n" +
"			<li class=\"tol\">Toll Number : 123-4568790</li>				\n" +
"			<li><a href=\"c1.html\" >Log out</a></li> \n" +
"			\n" +
"        </ul>\n" +
"		<div class=\"clearfix\"></div>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /top-header ---->\n" +
"<!--- header ---->\n" +
"<div class=\"header\">\n" +
"	<div class=\"container\">\n" +
"		<div class=\"logo wow fadeInDown animated\" data-wow-delay=\".5s\">\n" +
"			<a href=\"a1.html\">Home<span></span></a>	\n" +
"		</div>\n" +
"		<div class=\"bus wow fadeInUp animated\" data-wow-delay=\".5s\">\n" +
"        </div>\n" +
"		<div class=\"lock fadeInDown animated\" data-wow-delay=\".5s\"> \n" +
"            <li><div class=\"securetxt\">SAFE &amp; SECURE<br> ONLINE PAYMENTS</div></li>\n" +
"			<div class=\"clearfix\"></div>\n" +
"		</div>\n" +
"		<div class=\"clearfix\"></div>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /header ---->\n" +
"<!--- footer-btm ---->\n" +
"<div class=\"footer-btm wow fadeInLeft animated\" data-wow-delay=\".5s\">\n" +
"	<div class=\"container\">\n" +
"	<div class=\"navigation\">\n" +
"			<nav class=\"navbar navbar-default\">\n" +
"				<!-- Brand and toggle get grouped for better mobile display -->\n" +
"				<div class=\"navbar-header\">\n" +
"				  <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\">\n" +
"					<span class=\"sr-only\">Toggle navigation</span>\n" +
"					<span class=\"icon-bar\"></span>\n" +
"					<span class=\"icon-bar\"></span>\n" +
"					<span class=\"icon-bar\"></span>\n" +
"				  </button>\n" +
"				</div>\n" +
"				<!-- Collect the nav links, forms, and other content for toggling -->\n" +
"				<div class=\"collapse navbar-collapse nav-wil\" id=\"bs-example-navbar-collapse-1\">\n" +
"					<nav class=\"cl-effect-1\">\n" +
"						<ul class=\"nav navbar-nav\">\n" +
"							<li><a href=\"about.html\">About</a></li>\n" +
"								\n" +
"								<li><a href=\"agent.html\">Agent Registration</a></li>\n" +
"								<li><a href=\"terms.html\">Terms of Use</a></li>\n" +
"								<li>Need Help?<a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal3\"> / Write Us </a>  </li>\n" +
"								<div class=\"clearfix\"></div>\n" +
"						</ul>\n" +
"					</nav>\n" +
"				</div><!-- /.navbar-collapse -->	\n" +
"			</nav>\n" +
"		</div>\n" +
"		\n" +
"		<div class=\"clearfix\"></div>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /footer-btm ---->\n" +
"<!--- banner-1 ---->\n" +
"<div class=\"banner\">\n" +
"	<div class=\"container\">\n" +
"		<h1 class=\"wow zoomIn animated animated\" data-wow-delay=\".5s\" style=\"visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;\">Online Bus Booking System</h1>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /banner-1 ---->\n" +
"<!--- agent ---->\n" +
"<div class=\"agent\">\n" +
"	<div class=\"container\">\n" +
"		<div  class=\"col-md-6 agent-left wow fadeInDown animated\" data-wow-delay=\".5s\">\n" +
"			\n" +
"			<form method=\"post\" action=\"c2\">\n" +
"\n" +
"                                                  <center><h1>\n" +
"\n" +
"                                                   Click on Below Button to Get All Views\n" +
"\n" +
"                                                             </h1>\n" +
"                                                          <br>\n" +
"                                               <input type=\"submit\" value=\"view\"><center>\n" +
"                                                       </form>\n" +
"		</div>\n" +
"			<div class=\"clearfix\"></div>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /agent ---->\n" +
"<!--- footer-top ---->\n" +
"<div class=\"footer-top\">\n" +
"	<div class=\"container\">\n" +
"		<div class=\"col-md-6 footer-left wow fadeInRight animated\" data-wow-delay=\".5s\">\n" +
"			<h3>Bus Routes</h3>\n" +
"				<ul>\n" +
"					<li>Asansol-Durgapur </li>\n" +
"					<li>Asansol-Kolkata</li>\n" +
"					<li>Asansol-Karunamoyee</li>\n" +
"					<li>Durgapur-Kolkata</a></li>\n" +
"					<li>Durgapur-Karunamoyee</a></li>\n" +
"					<li>Burdwan-Kolkata</a></li>\n" +
"					<li>Burdwan-Karunamoyee</li>\n" +
"				</ul>\n" +
"		</div>\n" +
"		<div class=\"clearfix\"></div>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /footer-top ---->\n" +
"<!---copy-right ---->\n" +
"<div class=\"copy-right\">\n" +
"	<div class=\"container\">\n" +
"	\n" +
"		<div class=\"footer-social-icons wow fadeInDown animated animated\" data-wow-delay=\".5s\" style=\"visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;\">\n" +
"			<ul>\n" +
"				<li><a class=\"facebook\" href=\"#\"><span>Facebook</span></a></li>\n" +
"				<li><a class=\"twitter\" href=\"#\"><span>Twitter</span></a></li>\n" +
"				<li><a class=\"flickr\" href=\"#\"><span>Flickr</span></a></li>\n" +
"				<li><a class=\"googleplus\" href=\"#\"><span>Google+</span></a></li>\n" +
"				<li><a class=\"dribbble\" href=\"#\"><span>Dribbble</span></a></li>\n" +
"			</ul>\n" +
"		</div>\n" +
"		<p class=\"wow zoomIn animated animated\" data-wow-delay=\".5s\" style=\"visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;\">© 2016 Green Wheels . All Rights Reserved | Design by  <a href=\"http://w3layouts.com/\" target=\"_blank\">W3layouts</a> </p>\n" +
"	</div>\n" +
"</div>\n" +
"<!--- /copy-right ---->\n" +
"<!-- sign -->\n" +
"			\n" +
"<!-- //signin -->\n" +
"<!-- write us -->\n" +
"			<div class=\"modal fade\" id=\"myModal3\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\">\n" +
"				<div class=\"modal-dialog\" role=\"document\">\n" +
"					<div class=\"modal-content\">\n" +
"						<div class=\"modal-header\">\n" +
"							<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>						\n" +
"						</div>\n" +
"							<section>\n" +
"								<div class=\"modal-body modal-spa\">\n" +
"									<div class=\"writ\">\n" +
"										<h4>HOW CAN WE HELP YOU</h4>\n" +
"                                                                                                                                                                                         <form method=\"post\" action=\"\">\n" +
"											<ul>\n" +
"												<li class=\"na-me\">\n" +
"													<input class=\"name\" type=\"text\" value=\"Name\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Name';}\" required=\"\">\n" +
"												</li>\n" +
"												<li class=\"na-me\">\n" +
"													<input class=\"Email\" type=\"text\" value=\"Email\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Email';}\" required=\"\">\n" +
"												</li>\n" +
"												<li class=\"na-me\">\n" +
"													<input class=\"number\" type=\"text\" value=\"Mobile Number\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Mobile Number';}\" required=\"\">\n" +
"												</li>\n" +
"												<li class=\"na-me\">\n" +
"													<select id=\"country\" onchange=\"change_country(this.value)\" class=\"frm-field required sect\">\n" +
"														<option value=\"null\">Select Issue</option> 		\n" +
"														<option value=\"null\">Booking Issues</option>\n" +
"														<option value=\"null\">Bus Cancellation</option>\n" +
"														<option value=\"null\">Refund</option>\n" +
"														<option value=\"null\">Wallet</option>														\n" +
"													</select>\n" +
"												</li>\n" +
"												<li class=\"na-me\">\n" +
"													<select id=\"country\" onchange=\"change_country(this.value)\" class=\"frm-field required sect\">\n" +
"														<option value=\"null\">Select Issue</option> 		\n" +
"														<option value=\"null\">Booking Issues</option>\n" +
"														<option value=\"null\">Bus Cancellation</option>\n" +
"														<option value=\"null\">Refund</option>\n" +
"														<option value=\"null\">Wallet</option>														\n" +
"													</select>\n" +
"												</li>\n" +
"												<li class=\"descrip\">\n" +
"													<input class=\"special\" type=\"text\" value=\"Write Description\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Write Description';}\" required=\"\">\n" +
"												</li>\n" +
"													<div class=\"clearfix\"></div>\n" +
"											</ul>\n" +
"											<div class=\"sub-bn\">\n" +
"												\n" +
"													<button class=\"subbtn\">Submit</button>\n" +
"												\n" +
"											</div>\n" +
"                                                                                                                                                                                     </form>\n" +
"									</div>\n" +
"								</div>\n" +
"							</section>\n" +
"					</div>\n" +
"				</div>\n" +
"			</div>\n" +
"<!-- //write us -->\n" +
"</body>\n" +
"</html>");
                  
                   
               }
               else
               {
                   pw1.println("not found");
               }
               con.close();
         }  
                catch(Exception e)
              {
                  pw1.println(e);
              }

   
  }
} 