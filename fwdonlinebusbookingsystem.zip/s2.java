import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.servlet.*;
import javax.servlet.http.*;


public class s2 extends HttpServlet
{
     public void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
     {
         res.setContentType("text/html");
         PrintWriter pw=res.getWriter();
          String k3=req.getParameter("c2");
          String k4=req.getParameter("r2");
         try
         {
              HttpSession ses=req.getSession();//establishing a session
             ses.setAttribute("l6", k3);
              Class.forName("oracle.jdbc.driver.OracleDriver");
                 //registering type4 driver
               Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","ujjwal3","das1");
               Statement stmt=con.createStatement();
               String ql="insert into ud6 values('"+k3+"','"+k4+"')";
               int x=stmt.executeUpdate(ql);
               
               if(x>0)
               {
                  pw.println("<!--\n" +
"Author: W3layouts\n" +
"Author URL: http://w3layouts.com\n" +
"License: Creative Commons Attribution 3.0 Unported\n" +
"License URL: http://creativecommons.org/licenses/by/3.0/\n" +
"-->\n" +
"<!DOCTYPE html>\n" +
"<html>\n" +
"<head>\n" +
"<title>Bus Ticket Reservation Widget Flat Responsive Widget Template :: w3layouts</title>\n" +
"<!-- for-mobile-apps -->\n" +
"<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n" +
"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1\">\n" +
"<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" /> \n" +
"<meta name=\"keywords\" content=\"Bus Ticket Reservation Widget Responsive, Login form web template, Sign up Web Templates, Flat Web Templates, Login signup Responsive web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design\" />\n" +
"<!-- //for-mobile-apps -->\n" +
"<link href='//fonts1.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>\n" +
"<link href='//fonts1.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>\n" +
"<link rel=\"stylesheet\" type=\"text/css\" href=\"css1/jquery.seat-charts.css\">\n" +
"<link href=\"css1/style.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />\n" +
"<script src=\"js1/jquery-1.11.0.min.js\"></script>\n" +
"<script src=\"js1/jquery.seat-charts.js\"></script>\n" +
"<style>\n" +
  "\n" +
"    body {\n" +
"    width: 100%;\n" +
"    height: 100%;\n" +
"    background-image: url('banner.jpg');\n" +
"    background-repeat: no-repeat;\n" +
"}\n" +
"\n" +                        
"  input[type=text] {\n" +
"   background-color:green;\n" +
"    border: none;\n" +
"    color: white;\n" +
"    padding: 8px 16px;\n" +
"    text-decoration: none;\n" +
"    margin: 4px 2px;\n" +
"    cursor: pointer;\n" +
" }\n" +
"</style>\n" +
"</head>\n" +
"<body>\n" +
"	<div class=\"main\">\n" +
"		<h2>Book Your Seat Now?</h2>\n" +
"		<div class=\"wrapper\">\n" +
"			<div id=\"seat-map\">\n" +
"				<div class=\"front-indicator\"><h3>Front</h3></div>\n" +
"			</div>\n" +
"			<div class=\"booking-details\">\n" +
"						<div id=\"legend\"></div>\n" +
"						<h3> Selected Seats (<span id=\"counter\">0</span>):</h3>\n" +
"						<ul id=\"selected-seats\" class=\"scrollbar scrollbar1\"></ul>\n" +
"						\n" +
"						Total: <b>Rs. <span id=\"total\">0</span></b>\n" +
"						<form method=\"post\" action=\"g1\">\n" +
"                                                    <h3>Confirm to Pay:</h3>\n" +
"                                                  <input type=\"text\" name=\"tot\">\n" +
"                                                  <h3>No. of persons:</h3>\n" +
"                                                  <input type=\"text\" name=\"ps\">\n" +
"                                                   <h3>Seat No.:</h3>\n" +
"                                                  <input type=\"text\" name=\"s\">\n" +
"                                                   <input type=\"submit\"  value=\"pay\" class=\"checkout-button\">\n" +
"                                                  </form>\n" +
"						\n" +
"			</div>\n" +
"			<div class=\"clear\"></div>\n" +
"		</div>\n" +
"		<script>\n" +
"				var firstSeatLabel = 1;\n" +
"			\n" +
"				$(document).ready(function() {\n" +
"					var $cart = $('#selected-seats'),\n" +
"						$counter = $('#counter'),\n" +
"						$total = $('#total'),\n" +
"						sc = $('#seat-map').seatCharts({\n" +
"						map: [\n" +
"							'ff_ff',\n" +
"							'ff_ff',\n" +
"							'ff_ff',\n" +
"							'ff_ff',\n" +
"							'ff___',\n" +
"							'ff_ff',\n" +
"							'ff_ff',\n" +
"							'ff_ff',\n" +
"							'fffff',\n" +
"						],\n" +
"						seats: {\n" +
"							f: {\n" +
"								price   : 300,\n" +
"								classes : 'first-class', //your custom CSS class\n" +
"								category: 'First Class'\n" +
"							},\n" +
"							/*e: {\n" +
"								price   : 400,\n" +
"								classes : 'economy-class', //your custom CSS class\n" +
"								category: 'Economy Class'\n" +
"							}*/					\n" +
"						\n" +
"						},\n" +
"						naming : {\n" +
"							top : false,\n" +
"							getLabel : function (character, row, column) {\n" +
"								return firstSeatLabel++;\n" +
"							},\n" +
"						},\n" +

"						click: function () {\n" +
"							if (this.status() == 'available') {\n" +
"								//let's create a new <li> which we'll add to the cart items\n" +
"								$('<li>'+this.data().category+' : Seat no '+this.settings.label+': <b>  Rs. '+this.data().price+'</b> <a href=\"#\" class=\"cancel-cart-item\">[cancel]</a></li>')\n" +
"									.attr('id', 'cart-item-'+this.settings.id)\n" +
"									.data('seatId', this.settings.id)\n" +
"									.appendTo($cart);\n" +
"								\n" +
"								/*\n" +
"								 * Lets update the counter and total\n" +
"								 *\n" +
"								 * .find function will not find the current seat, because it will change its stauts only after return\n" +
"								 * 'selected'. This is why we have to add 1 to the length and the current seat price to the total.\n" +
"								 */\n" +
"								$counter.text(sc.find('selected').length+1);\n" +
"								$total.text(recalculateTotal(sc)+this.data().price);\n" +
"								\n" +
"								return 'selected';\n" +
"							} else if (this.status() == 'selected') {\n" +
"								//update the counter\n" +
"								$counter.text(sc.find('selected').length-1);\n" +
"								//and total\n" +
"								$total.text(recalculateTotal(sc)-this.data().price);\n" +
"							\n" +
"								//remove the item from our cart\n" +
"								$('#cart-item-'+this.settings.id).remove();\n" +
"							\n" +
"								//seat has been vacated\n" +
"								return 'available';\n" +
"							} else if (this.status() == 'unavailable') {\n" +
"								//seat has been already booked\n" +
"								return 'unavailable';\n" +
"							} else {\n" +
"								return this.style();\n" +
"							}\n" +
"						}\n" +
"					});\n" +
"\n" +
"					//this will handle \"[cancel]\" link clicks\n" +
"					$('#selected-seats').on('click', '.cancel-cart-item', function () {\n" +
"						//let's just trigger Click event on the appropriate seat, so we don't have to repeat the logic here\n" +
"						sc.get($(this).parents('li:first').data('seatId')).click();\n" +
"					});\n" +
"\n" +
"					//let's pretend some seats have already been booked\n" +
"					//sc.get(['1_2', '4_1', '7_1', '7_2']).status('unavailable');\n" +
"			\n" +
"			});\n" +
"\n" +
"			function recalculateTotal(sc) {\n" +
"				var total = 0;\n" +
"			\n" +
"				//basically find every selected seat and sum its price\n" +
"				sc.find('selected').each(function () {\n" +
"					total += this.data().price;\n" +
"				});\n" +
"				\n" +
"				return total;\n" +
"			}\n" +
"		</script>\n" +
"	</div>\n" +
"	<p class=\"copy_rights\">&copy; 2016 Bus Ticket Reservation Widget. All Rights Reserved | Design by  <a href=\"http://w3layouts.com/\" target=\"_blank\"> W3layouts</a></p>\n" +
"<script src=\"js1/jquery.nicescroll.js\"></script>\n" +
"<script src=\"js1/scripts.js\"></script>\n" +
"</body>\n" +
"</html>\n" +
"\n" +
"");
                   
                     
               }
               else
               {
                  pw.println("insert unsuccess");
                 
               }
               con.close();
           }
              catch(Exception e)
              {
                  pw.println(e);
              }
   
      }
}