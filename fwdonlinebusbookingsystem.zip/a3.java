import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import javax.servlet.*;
import javax.servlet.http.*;



public class a3 extends HttpServlet
{
  public void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
  {
      res.setContentType("text/html");
      PrintWriter pw1=res.getWriter();
      
     
      try
         {
              Class.forName("oracle.jdbc.driver.OracleDriver");
                 //registering type4 driver
               Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","ujjwal3","das1");
               Statement stmt=con.createStatement();
               String q2="select * from alt ";
              
              ResultSet rs=stmt.executeQuery(q2);
             
              pw1.println("<html>\n" +
"    <head>\n" +
"         </head>\n"+
"    <body>\n" +
"            <table border=\"1\" >\n" +
"                <tr>\n" +
"                    <th>Name:</th>\n" +
"                    <th>Source:</th>\n" +
"                    <th>Destination:</th>\n" +
"                    <th>Journey Date</th>\n" +
"                    <th>Journey Time</th>\n" +
"                      <th>Total Price</th>\n" +
"                      <th>No. of persons</th>\n" +
"                      <th>Email:</th>\n" +
"                    <th>Phone no.</th>\n" +
"                     <th>Passenger's name</th> \n" +
"                     <th>Card Type</th> \n" +
"                </tr>\n" +
"            </table>    \n" +
"      </body>\n" +
"</html>");
             /*HttpSession ses=req.getSession();
            String v1=(String)ses.getAttribute("l1");
            String v2=(String)ses.getAttribute("l3");
            String v3=(String)ses.getAttribute("l4");
            String v4=(String)ses.getAttribute("l5");
            String v5=(String)ses.getAttribute("l6");
            Integer v6=(Integer)ses.getAttribute("l7");
            Integer v7=(Integer)ses.getAttribute("l8");
            String v8=(String)ses.getAttribute("l9");
            String v9=(String)ses.getAttribute("l10");
            String v10=(String)ses.getAttribute("l11");
            String v11=(String)ses.getAttribute("l12");
               
             pw1.println("<table border=1>");
               
               
                pw1.println("<tr><td>"+v1+"</td><td>"+v2+"</td><td>"+v3+"</td><td>"+v4+"</td><td>"+v5+"</td><td>"+v6+"</td><td>"+v7+"</td><td>"+v8+"</td><td>"+v9+"</td><td>"+v10+"</td><td>"+v11+"</td></tr>");
              
               
               pw1.println("</table>");
               /*if(x>0)
               {
                   pw1.println("success");
               }*/ 
                pw1.println("<body bgcolor=levendor><table border=1>");
               while(rs.next())
               {
                pw1.println("<tr><td>"+rs.getString(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td><td>"+rs.getString(4)+"</td><td>"+rs.getString(5)+"</td><td>"+rs.getString(6)+"</td><td>"+rs.getString(7)+"</td><td>"+rs.getString(8)+"</td><td>"+rs.getString(9)+"</td><td>"+rs.getString(10)+"</td><td>"+rs.getString(11)+"</td></tr>");
               }
               pw1.println("</table><body>");
               
               con.close();
          }  
                catch(Exception e)
              {
                  pw1.println(e);
              }

   
  }
} 